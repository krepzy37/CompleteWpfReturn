﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.IO;

namespace wpfujra
{
    /// <summary>
    /// Interaction logic for DataAnalysisWindow.xaml
    /// </summary>
    public partial class DataAnalysisWindow : Window
    {
        List<Utas> utasok = new List<Utas>();

        public DataAnalysisWindow()
        {
            InitializeComponent();
        }
        #region 2. feladat
        private void OnLoadData_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string[] lines = File.ReadAllLines(@"..\..\..\src\utasadat.txt");
                utasok = lines.Select(line => new Utas(line)).ToList();

                ResultTextBox.Text = $"{utasok.Count} utas adat lett beolvasva.";
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Hiba történt az adatok beolvasása közben: {ex.Message}");
            }
        }
        #endregion
        #region 3. feladat
        private void OnPassengerCount_Click(object sender, RoutedEventArgs e)
        {
            int count = utasok.Count;
            ResultTextBox.Text = $"Összesen {count} utas szeretett volna felszállni a buszra.";
        }
        #endregion
        #region 4. feladat
        private void OnRejectedPassengers_Click(object sender, RoutedEventArgs e)
        {

            int rejectedCount = utasok.Count(utas =>
                (utas.JegyBerletTipus == "JGY" && int.Parse(utas.Ervenyesseg) == 0) ||
                (utas.JegyBerletTipus != "JGY" && DateTime.ParseExact(utas.Ervenyesseg, "yyyyMMdd", null) < utas.FelszallDatumIdo.Date));


            ResultTextBox.Text = $"Összesen {rejectedCount} utast kellett elutasítani lejárt jegy vagy bérlet miatt.";
        }
        #endregion
        #region 5. feladat
        private void OnMostPassengersStop_Click(object sender, RoutedEventArgs e)
        {
            var stopGroups = utasok.GroupBy(utas => utas.Sorszám)
                                   .OrderByDescending(g => g.Count())
                                   .ThenBy(g => g.Key)
                                   .FirstOrDefault();

            ResultTextBox.Text = $"A legtöbb utas a {stopGroups?.Key}. megállóban próbált felszállni.";
        }
        #endregion
        #region 6. feladat
        private void OnDiscountedPassengers_Click(object sender, RoutedEventArgs e)
        {
            var discounted = new HashSet<string> { "TAB", "NYB" };
            var free = new HashSet<string> { "NYP", "RVS", "GYK" };

            int discountedCount = utasok.Count(utas => discounted.Contains(utas.JegyBerletTipus));
            int freeCount = utasok.Count(utas => free.Contains(utas.JegyBerletTipus));

            ResultTextBox.Text = $"{discountedCount} kedvezményes és {freeCount} ingyenes utas szállt fel érvényes bérlettel.";
        }
        #endregion
        #region 7. feladat

        private void OnWarnPassengers_Click(object sender, RoutedEventArgs e)
        {

            var warningList = utasok.Where(utas =>
                utas.JegyBerletTipus != "JGY" &&
                (DateTime.ParseExact(utas.Ervenyesseg, "yyyyMMdd", null) - utas.FelszallDatumIdo.Date).Days <= 3)
                .Select(utas => $"{utas.KartyaId} {utas.Ervenyesseg}");


            File.WriteAllLines(@"..\..\..\src\figyelmeztetes.txt", warningList);
            ResultTextBox.Text = $"{warningList.Count()} utas figyelmeztetése lett mentve a figyelmeztetes.txt fájlba.";
        }
        #endregion
    }
}
