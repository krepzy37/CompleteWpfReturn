﻿using System.IO;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace wpfujra
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();

            
            comboMegallo.Items.Add("Válasszon megállót!");
            for (int i = 0; i <= 29; i++)
            {
                comboMegallo.Items.Add(i.ToString());
            }
            comboMegallo.SelectedIndex = 0;

            
            comboBerletTipus.Items.Add("Válasszon típust!");
            comboBerletTipus.Items.Add("FEB");
            comboBerletTipus.Items.Add("TAB");
            comboBerletTipus.Items.Add("NYB");
            comboBerletTipus.Items.Add("NYP");
            comboBerletTipus.Items.Add("RVS");
            comboBerletTipus.Items.Add("GYK");
            comboBerletTipus.SelectedIndex = 0;

            
            dateFelszallasDatum.SelectedDate = DateTime.Today;

            
            groupBerlet.Visibility = Visibility.Collapsed;
            groupJegy.Visibility = Visibility.Collapsed;

            // hány db karakter van
            labelFelhasznalhatoJegy.Content = "0db";
        }

        private void textKartyaAzonosito_TextChanged(object sender, TextChangedEventArgs e)
        {
            labelKarakterSzam.Content = textKartyaAzonosito.Text.Length.ToString();
        }

        private void RadioButton_Checked(object sender, RoutedEventArgs e)
        {
            if (radioBerlet.IsChecked == true)
            {
                groupBerlet.Visibility = Visibility.Visible;
                groupJegy.Visibility = Visibility.Collapsed;
            }
            else if (radioJegy.IsChecked == true)
            {
                groupBerlet.Visibility = Visibility.Collapsed;
                groupJegy.Visibility = Visibility.Visible;
            }
        }

        private void sliderFelhasznalhatoJegy_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            labelFelhasznalhatoJegy.Content = $"{(int)sliderFelhasznalhatoJegy.Value}db";
        }

        private void OnOpenDataAnalysis_Click(object sender, RoutedEventArgs e)
        {
            //DateTime carryDatum = dateFelszallasDatum.SelectedDate.Value.Date;
            DataAnalysisWindow dataWindow = new DataAnalysisWindow();
            dataWindow.Show();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {

            if (comboMegallo.SelectedIndex == 0)
            {
                MessageBox.Show("Nem választott megállót!", "Hiba", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            if (dateFelszallasDatum.SelectedDate == null)
            {
                MessageBox.Show("Nem adott meg dátumot!", "Hiba", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            string ido = textFelszallasIdo.Text;
            if (!TimeSpan.TryParseExact(ido, "hh\\:mm", null, out TimeSpan felszallasIdo))
            {
                MessageBox.Show("A felszállás időpontja nem megfelelő formátumú! (óó:pp)", "Hiba", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            if (textKartyaAzonosito.Text.Length != 7)
            {
                MessageBox.Show("A kártya azonosítója nem hét karakter hosszú!", "Hiba", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            if (!int.TryParse(textKartyaAzonosito.Text, out int kartyaAzonosito) || kartyaAzonosito <= 0)
            {
                MessageBox.Show("A kártya azonosítója nem pozitív egész szám!", "Hiba", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            string jegyBerletTipus = "";
            string ervenyesseg = "";

            if (radioBerlet.IsChecked == true)
            {
                if (comboBerletTipus.SelectedIndex == 0)
                {
                    MessageBox.Show("Nem adta meg a bérlet típusát!", "Hiba", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }

                if (dateBerletErvenyesseg.SelectedDate == null)
                {
                    MessageBox.Show("Nem adta meg a bérlet érvényességi idejét!", "Hiba", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }

                jegyBerletTipus = comboBerletTipus.SelectedItem.ToString();
                ervenyesseg = dateBerletErvenyesseg.SelectedDate.Value.ToString("yyyyMMdd");
            }
            else if (radioJegy.IsChecked == true)
            {
                jegyBerletTipus = "JGY";
                ervenyesseg = ((int)sliderFelhasznalhatoJegy.Value).ToString();
            }
            else
            {
                MessageBox.Show("Nem választotta ki, hogy bérlet vagy jegy!", "Hiba", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            string sorszam = comboMegallo.SelectedItem.ToString();
            DateTime felszallasDatumIdo = dateFelszallasDatum.SelectedDate.Value.Date + felszallasIdo;
            string datumIdo = felszallasDatumIdo.ToString("yyyyMMdd-HHmm");
            string ujSor = $"{sorszam} {datumIdo} {kartyaAzonosito} {jegyBerletTipus} {ervenyesseg}";

            try
            {
                File.AppendAllText(@"..\..\..\src\utasadat.txt", ujSor + Environment.NewLine);
                MessageBox.Show("A felszállás tárolása sikeres volt!", "Információ", MessageBoxButton.OK, MessageBoxImage.Information);

                comboMegallo.SelectedIndex = 0;
                dateFelszallasDatum.SelectedDate = DateTime.Today;
                textFelszallasIdo.Text = "";
                textKartyaAzonosito.Text = "";
                radioBerlet.IsChecked = false;
                radioJegy.IsChecked = false;
                groupBerlet.Visibility = Visibility.Collapsed;
                groupJegy.Visibility = Visibility.Collapsed;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Hiba történt az adatok mentésekor: " + ex.Message, "Hiba", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}