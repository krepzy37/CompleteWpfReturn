﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Globalization;

namespace wpfujra
{
    internal class Utas
    {
        public int Sorszám { get; set; }
        public DateTime FelszallDatumIdo { get; set; }
        public int KartyaId { get; set; }
        public string JegyBerletTipus { get; set; }
        public string Ervenyesseg { get; set; }
        public Utas(string deez)
        {
            var n = deez.Split(' ');
            Sorszám = int.Parse(n[0]);
            FelszallDatumIdo = DateTime.ParseExact(n[1], "yyyyMMdd-HHmm", CultureInfo.InvariantCulture);
            KartyaId = int.Parse(n[2]);
            JegyBerletTipus = n[3];
            Ervenyesseg = n[4];
        }
    }
}
